n = int(raw_input().strip())
print sum(map(int, raw_input().strip().split(' ')))