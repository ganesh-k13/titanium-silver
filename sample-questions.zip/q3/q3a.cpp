#include <iostream>
#include <algorithm>  
using namespace std;

int main(){
    int test;
    cin >> test;
    for(int i=0;i<test;i++) {
        string inp;
        cin >> inp;
        if (next_permutation(inp.begin(), inp.end()) == false ) {
            cout << "no answer" << endl;
        }
        else if(i!=test-1){
            cout << inp << endl;
        }
        else{
            cout << inp;
        }
    }
    return 0;
}