// this code is wrong
#include <stdio.h>
#include <string.h>

char s[500];
int main()
{
    int t,j;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%s",s);
        int l=strlen(s);
        int i=l-1;
        int f[300]={0};
        while(i>0&&s[i]<=s[i-1])
        {
            f[s[i]]++;
            i--;
        }
        if(i)
        {
            f[s[i]]++;
            f[s[i-1]]++;
            for(j=0;j<i-1;j++)
                printf("%c",s[j]);
            for(j=s[i-1]+1;j<='z';j++)
                if(f[j])
                    break;
        f[j]--;
            printf("%c",j);
            for(i='a';i<='z';i++)
                for(j=0;j<f[i];j++)
                    printf("%c",i);
            printf("\n");

        }
        else
            printf("no answer\n");
    }
    return 0;
}